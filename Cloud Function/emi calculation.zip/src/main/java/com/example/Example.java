package com.example;

import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import java.io.BufferedWriter;
import org.apache.commons.math3.analysis.function.Pow;

public class Example implements HttpFunction {
  @Override
  public void service(HttpRequest request, HttpResponse response) throws Exception {
    response.setStatusCode(200);
    response.setContentType("text/html");
    var writer =response.getWriter();
    var  p = 1000000.00;
		var  r =  10.5;
    var  t  = 5.0;               
    r  = r/(12*100);
    t   = t*12;
    Pow  p1=new Pow();
    var emi = (p*r*p1.value(1+r,t))/p1.value(1+r,t)-1;
    System.out.println("My Monthly EMI is:"+ emi);
    writer.write("The EMI is"+emi);
  }
}
