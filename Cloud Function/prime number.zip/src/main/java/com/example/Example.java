package com.example;

import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import java.io.BufferedWriter;
import org.apache.commons.math3.primes.Primes;

public class Example implements HttpFunction {
  @Override
  public void service(HttpRequest request, HttpResponse response) throws Exception {
      response.setStatusCode(200);
      response.setContentType("text/html");
      var writer=response.getWriter();
      try{
        var num = 20;
        writer.write(num + "is a prime number "+ Primes.isPrime(num));
        System.out.println(num + "is a prime number "+ Primes.isPrime(num));
      }catch(Exception e){
        writer.write("Please provide a valid number");
    } 
  }
}
